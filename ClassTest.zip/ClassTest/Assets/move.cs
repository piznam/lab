﻿using UnityEngine;



public class move : MonoBehaviour {

    public float speed = 4f;

    //cant remeber off hand how to to make array of game objects have to do it long way
    //waypoints
    public GameObject shell;
    public GameObject shell1;
    public GameObject shell2;
    public GameObject shell3;
    public GameObject shell4;
    public GameObject shell5;
    public GameObject shell6;
    public GameObject shell7;
    public GameObject shell8;


    public GameObject target;
    void Start()
    {
        

    }
    // Update is called once per frame
    void Update()
    {
        //moves object towards target 
        Vector3 dir = target.transform.position - transform.position;
        transform.Translate(dir.normalized * speed * Time.deltaTime);

        //the long way ifs to change target of way point
        if (Vector3.Distance(transform.position, target.transform.position) <= 0.3f)
        {
           if(target == shell)
                target = shell1;

           else if(target == shell1)
                target = shell2;

            else if (target == shell2)
                target = shell3;

            else if (target == shell3)
                target = shell4;

            else if (target == shell4)
                target = shell5;

            else if (target == shell5)
                target = shell6;

            else if (target == shell6)
                target = shell7;

            else if (target == shell7)
                target = shell8;

            else if (target == shell8)
                target = shell;

        }

    }

}


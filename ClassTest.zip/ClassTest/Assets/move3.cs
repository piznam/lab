﻿using UnityEngine;


public class move3 : MonoBehaviour
{

    public float speed = 4f;

    //forgot how to make array of game objects have to do it long way
    public GameObject shell;
    public GameObject shell1;
    public GameObject shell2;
    public GameObject shell3;
    public GameObject shell4;
    public GameObject shell5;
    public GameObject shell6;
    public GameObject shell7;
    public GameObject shell8;
    public GameObject shell9;
    public GameObject shell10;
    public GameObject shell11;
    public GameObject shell12;
    public GameObject shell13;



    public GameObject target;
    void Start()
    {


    }
    // Update is called once per frame
    void Update()
    {

        Vector3 dir = target.transform.position - transform.position;
        transform.Translate(dir.normalized * speed * Time.deltaTime);

        if (Vector3.Distance(transform.position, target.transform.position) <= 0.3f)
        {
            if (target == shell)
            {
                target = shell1;

            }
            else if (target == shell1)
            {
                target = shell2;
            }
            else if (target == shell2)
            {
                target = shell3;
            }
            else if (target == shell3)
            {
                target = shell4;
            }
            else if (target == shell4)
            {
                target = shell5;
            }
            else if (target == shell5)
            {
                target = shell6;
            }
            else if (target == shell6)
            {
                target = shell7;
            }
            else if (target == shell7)
            {
                target = shell8;
            }
            else if (target == shell8)
            {
                target = shell9;
            }
            else if (target == shell9)
            {
                target = shell10;
            }
            else if (target == shell10)
            {
                target = shell11;
            }
            else if (target == shell11)
            {
                target = shell12;
            }
            else if (target == shell12)
            {
                target = shell13;
            }
            else if (target == shell13)
            {
                target = shell;
            }




        }

    }

}

